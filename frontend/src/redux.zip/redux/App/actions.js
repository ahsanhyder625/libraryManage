import { SET_CITY_DATA, SET_POLLING_STATION_DATA } from './actionTypes';

export const setCityData = (payload) => ({
    type: SET_CITY_DATA,
    payload
});

export const setPollingStationData = (payload) => ({
    type: SET_POLLING_STATION_DATA,
    payload
});


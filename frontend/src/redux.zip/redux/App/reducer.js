import { SET_CITY_DATA, SET_POLLING_STATION_DATA } from './actionTypes';


let initState = {
    cityData: [],
    pollingStationData: []
   
};

const reducer = (state = initState, { type, payload }) => {
    switch (type) {
        
        case SET_CITY_DATA:
            return {
                ...state,
                cityData: payload
            };
        case SET_POLLING_STATION_DATA:
            return {
                ...state,
                pollingStationData: payload
            };

        default:
            return state;
    }
};

export default reducer;